#version 300 es
precision mediump float;


out vec4 Color;

void main()
{
    Color = vec4(1.0,0.0,0.0,1.0);
}